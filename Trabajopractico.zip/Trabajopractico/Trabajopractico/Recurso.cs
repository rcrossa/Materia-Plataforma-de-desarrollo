﻿using System;
namespace Trabajopractico
{
    public class Recurso
    {

        public string nombre { get; set; }
        public Usuario usuario { get; set; }

        //public Recurso(string nombre, Usuario usuario)
        //{
        //    this.nombre = nombre;
        //    this.usuario = usuario;
        //}

    }
}
