﻿using System;
namespace Trabajopractico
{
    public class Usuario
    {
        public string nombre { get; set; }
         public Usuario usuario { get; set; }

        //public Usuario(string nombre, Usuario usuario)
        //{
        //    this.nombre = nombre;
        //    this.usuario = usuario;
        //}

        //public Usuario()
        //{
        //}
    }
}
